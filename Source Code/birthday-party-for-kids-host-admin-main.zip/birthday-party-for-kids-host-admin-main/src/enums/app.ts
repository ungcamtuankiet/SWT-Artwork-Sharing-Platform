enum AppConstants {
    ACCESS_TOKEN = 'access_token',
    REFRESH_TOKEN = 'refresh_token',
    USER = "user_information",
    ROLE = "role"
  }
  
  export default AppConstants;